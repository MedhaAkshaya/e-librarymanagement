package com.archivalia.fine;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Map;
@RestController @RequestMapping("/api/fines")
public class FineController {
 @GetMapping("/calculate")
 public Map<String,Object> calculate(@RequestParam String dueDate,@RequestParam(required=false) String returnDate,@RequestParam(defaultValue="5") double ratePerDay){
  LocalDate due=LocalDate.parse(dueDate);LocalDate actual=returnDate==null?LocalDate.now():LocalDate.parse(returnDate);
  long days=Math.max(0,ChronoUnit.DAYS.between(due,actual));return Map.of("dueDate",due.toString(),"returnDate",actual.toString(),"overdueDays",days,"ratePerDay",ratePerDay,"fineAmount",days*ratePerDay);
 }
}
